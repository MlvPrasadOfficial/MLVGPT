
class Object:
    def __init__(self):
        self.updated_state=None
        self.predicted_state=None
        self.detected_state=None
        self.updated_covariance=None
        self.predicted_covariance=None
        self.prediction_score=None
        self.score=None
        self.features=None
